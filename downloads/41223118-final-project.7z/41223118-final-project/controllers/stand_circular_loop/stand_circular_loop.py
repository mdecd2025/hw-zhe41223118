from controller import Robot, Keyboard, GPS, InertialUnit, Receiver, Emitter
import math

def move_sideways_precise(robot, gps, imu, wheels, distance, fast_velocity=10.0, slow_velocity=2.0, tolerance=0.01):
    start_pos = gps.getValues()
    yaw = imu.getRollPitchYaw()[2]
    side_vec = (math.sin(yaw), math.cos(yaw))
    timestep = int(robot.getBasicTimeStep())
    while robot.step(timestep) != -1:
        now_pos = gps.getValues()
        dx = now_pos[0] - start_pos[0]
        dy = now_pos[1] - start_pos[1]
        side_moved = dx * side_vec[0] + dy * side_vec[1]
        remain = distance - side_moved
        if abs(remain) < tolerance:
            break
        threshold = abs(distance) / 10.0
        v = fast_velocity if abs(remain) > threshold else slow_velocity
        direction = 1 if remain >= 0 else -1
        wheels[0].setVelocity(direction * v)
        wheels[1].setVelocity(-direction * v)
        wheels[2].setVelocity(-direction * v)
        wheels[3].setVelocity(direction * v)
    for w in wheels:
        w.setVelocity(0.0)
    print("Sideways move finished")

robot = Robot()
timestep = int(robot.getBasicTimeStep())

side_emitter = robot.getDevice("score_emitter")
side_receiver = robot.getDevice("rcv")
side_receiver.enable(timestep)

gps = robot.getDevice("gps")
imu = robot.getDevice("imu")
gps.enable(timestep)
imu.enable(timestep)

# 加回感測器
sensor = robot.getDevice('sensor')
sensor.enable(timestep)
score_to_send = 2
cooldown = 1.0
score = 0
last_score_time = 0

wheels = [robot.getDevice("wheel5"), robot.getDevice("wheel6"), robot.getDevice("wheel7"), robot.getDevice("wheel8")]
for w in wheels:
    w.setPosition(float('inf'))
    w.setVelocity(0)

keyboard = Keyboard()
keyboard.enable(timestep)

for _ in range(10):
    robot.step(timestep)

print("等待 J 訊號觸發平移... (J/K 鍵也可以測手動)")

last_signal = None  # 記錄上次收到的訊號
first_signal = True # 第一次訊號特殊處理

def ad_to_distance(ad_value):
    # 若有lookup table可自行調整
    # 這裡給一個簡化式
    # 假設0~1000對應0.18~0.00
    if ad_value >= 1000:
        return 0.00
    if ad_value <= 0:
        return 0.18
    return 0.18 - (ad_value / 1000.0) * 0.18

while robot.step(timestep) != -1:
    # 感測器score計分（每秒最多1次，距離小於0.11才得分，並發送分數）
    sensor_value = sensor.getValue()
    distance = ad_to_distance(sensor_value)
    current_time = robot.getTime()
    if distance < 0.1766 and (current_time - last_score_time) > cooldown:
        score += score_to_send
        print("得分")
        print(distance)
        side_emitter.send(str(score_to_send).encode('utf-8'))
        last_score_time = current_time

    # 1. 自動訊號
    while side_receiver.getQueueLength() > 0:
        msg = side_receiver.getString().strip().upper()
        if first_signal:
            print(f"首次收到 {msg} 訊號，不作動，之後收到新訊號才會觸發平移。")
            first_signal = False
        elif msg == "J" and msg != last_signal:
            print("收到新 J 訊號，開始平移 +0.5m")
            move_sideways_precise(robot, gps, imu, wheels, 1.0)
            side_emitter.send("J".encode("utf-8"))
            print("平移完成，已再次發送 J 訊號")
        last_signal = msg
        side_receiver.nextPacket()

    # 2. 手動測試（仍然支援 J/K 鍵）
    key = keyboard.getKey()
    if key == ord('K') or key == ord('k'):
        move_sideways_precise(robot, gps, imu, wheels, -0.5)
        side_emitter.send("K".encode("utf-8"))
        print("手動平移-0.5m並發送K")