from controller import Supervisor, Emitter, Receiver, Keyboard

supervisor = Supervisor()
emitter = supervisor.getDevice('em')
receiver = supervisor.getDevice('22')  # 你訊號來源的 Receiver 名稱
receiver.enable(int(supervisor.getBasicTimeStep()))
keyboard = Keyboard()
keyboard.enable(int(supervisor.getBasicTimeStep()))
timestep = int(supervisor.getBasicTimeStep())

BALL_TO_SWING_DELAY = 1    # a -> m
SWING_TO_RESET_DELAY = 1   # m -> k
RESET_TO_NEXTBALL_DELAY = 0.5  # k -> J
PRE_SEQUENCE_DELAY = 5.0  # <== 新增這個, 收到J後的延遲秒數（可調整）

WAITING_FOR_TRIGGER = 0
WAITING_BEFORE_SEQUENCE = 10   # <== 新增這個狀態
RUNNING_SEQUENCE = 1
WAITING_FOR_J = 2

state = WAITING_FOR_TRIGGER
sequence_state = 0
timer = 0

def start_sequence():
    global state, timer
    state = WAITING_BEFORE_SEQUENCE
    timer = 0

while supervisor.step(timestep) != -1:
    # 1. 鍵盤啟動（僅第一次有效）
    if state == WAITING_FOR_TRIGGER:
        key = keyboard.getKey()
        if key == ord('J') or key == ord('j'):
            print("手動J鍵啟動循環")
            start_sequence()
    # 2. 監聽訊號啟動（僅在等待訊號狀態）
    elif state == WAITING_FOR_J:
        while receiver.getQueueLength() > 0:
            msg = receiver.getString().strip().upper()
            receiver.nextPacket()
            if msg == "J":
                print("收到J訊號，啟動自動循環")
                start_sequence()

    # 3. 收到J後延遲（可調整秒數）
    if state == WAITING_BEFORE_SEQUENCE:
        timer += timestep / 1000
        if timer >= PRE_SEQUENCE_DELAY:
            print(f"J訊號後延遲 {PRE_SEQUENCE_DELAY} 秒結束，開始AMK序列")
            state = RUNNING_SEQUENCE
            sequence_state = 0
            timer = 0

    # 4. 執行 a→m→k→發J 的序列
    if state == RUNNING_SEQUENCE:
        timer += timestep / 1000
        if sequence_state == 0:
            emitter.send("a".encode('utf-8'))
            print("發送 a")
            timer = 0
            sequence_state = 1
        elif sequence_state == 1 and timer >= BALL_TO_SWING_DELAY:
            emitter.send("m".encode('utf-8'))
            print("發送 m")
            timer = 0
            sequence_state = 2
        elif sequence_state == 2 and timer >= SWING_TO_RESET_DELAY:
            emitter.send("k".encode('utf-8'))
            print("發送 k")
            timer = 0
            sequence_state = 3
        elif sequence_state == 3 and timer >= RESET_TO_NEXTBALL_DELAY:
            print("循環序列結束，發送J訊號")
            emitter.send("J".encode('utf-8'))  # 通知對方進入下一步
            state = WAITING_FOR_J  # 等待對方的J訊號