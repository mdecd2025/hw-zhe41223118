from controller import Robot, Keyboard
import math

deg = math.pi/180

# 常數設定
TIME_STEP = 16  # 模擬時間步長（毫秒）
MAX_VELOCITY = 10.0

# 初始化機器人
robot = Robot()

# 初始化鍵盤
keyboard = Keyboard()
keyboard.enable(TIME_STEP)
imu = robot.getDevice("imu")
imu.enable(TIME_STEP)
gps = robot.getDevice("gps")
gps.enable(TIME_STEP)

# 取得馬達裝置
wheel1 = robot.getDevice("wheel5")  # 前右輪
wheel2 = robot.getDevice("wheel6")  # 前左輪
wheel3 = robot.getDevice("wheel7")  # 後右輪
wheel4 = robot.getDevice("wheel8")  # 後左輪

for wheel in [wheel1, wheel2, wheel3, wheel4]:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)

def set_wheel_velocity(v1, v2, v3, v4):
    wheel1.setVelocity(v1)
    wheel2.setVelocity(v2)
    wheel3.setVelocity(v3)
    wheel4.setVelocity(v4)

def get_yaw():
    return imu.getRollPitchYaw()[2]

def angle_diff(a, b):
    d = a - b
    while d > math.pi:
        d -= 2 * math.pi
    while d < -math.pi:
        d += 2 * math.pi
    return d

def rotate_by_angle(target_angle_deg, fast_velocity=4.0, slow_velocity=1.0, tolerance_deg=0.5):
    start_yaw = get_yaw()
    target_rad = math.radians(target_angle_deg)
    slow_zone = math.radians(8)  # 進入8度內就降速
    direction = 1 if target_angle_deg > 0 else -1
    set_wheel_velocity(-direction*fast_velocity, direction*fast_velocity, -direction*fast_velocity, direction*fast_velocity)
    while robot.step(TIME_STEP) != -1:
        now_yaw = get_yaw()
        turned = angle_diff(now_yaw, start_yaw)
        remain = abs(target_rad) - abs(turned)
        if remain < slow_zone:
            set_wheel_velocity(-direction*slow_velocity, direction*slow_velocity, -direction*slow_velocity, direction*slow_velocity)
        if remain < math.radians(tolerance_deg):
            break
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(8):
        robot.step(TIME_STEP)
    # print(f"Yaw changed by {math.degrees(turned):.2f} degrees")

def get_position():
    pos = gps.getValues()
    return (pos[0], pos[1])

def angle_between_vectors(ax, ay, bx, by):
    norm_a = math.hypot(ax, ay)
    norm_b = math.hypot(bx, by)
    if norm_a == 0 or norm_b == 0:
        return 0
    ax, ay = ax / norm_a, ay / norm_a
    bx, by = bx / norm_b, by / norm_b
    dot = ax * bx + ay * by
    det = ax * by - ay * bx
    angle_rad = math.atan2(det, dot)
    return math.degrees(angle_rad)

def move_to_point_and_face_to(target_point, face_to_point, tolerance_pos=0.03):
    fast_velocity = 6.0
    slow_velocity = 1.0
    MAX_STEP = 3000
    # === 第一階段：轉向目標點 ===
    now_pos = get_position()
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    tar_vec = (target_point[0] - now_pos[0], target_point[1] - now_pos[1])
    angle1 = angle_between_vectors(head_vec[0], head_vec[1], tar_vec[0], tar_vec[1])
    if abs(angle1) > 1.0:
        rotate_by_angle(angle1)
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(8):
        robot.step(TIME_STEP)
    # === 第二階段：前進到目標點 ===
    step = 0
    arrived = False
    while step < MAX_STEP:
        robot.step(TIME_STEP)
        now_pos = get_position()
        dx = target_point[0] - now_pos[0]
        dy = target_point[1] - now_pos[1]
        dist = math.hypot(dx, dy)
        if dist < tolerance_pos:
            arrived = True
            break
        v = fast_velocity if dist > 0.2 else slow_velocity
        set_wheel_velocity(v, v, v, v)
        step += 1
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(18):
        robot.step(TIME_STEP)
    # === 第三階段：修正面向 ===
    now_pos = get_position()
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    face_vec = (face_to_point[0] - now_pos[0], face_to_point[1] - now_pos[1])
    angle2 = angle_between_vectors(head_vec[0], head_vec[1], face_vec[0], face_vec[1])
    if abs(angle2) > 1.0:
        rotate_by_angle(angle2)
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(18):
        robot.step(TIME_STEP)

print("WASD鍵控制移動，F鍵右旋90度，G鍵左旋90度，Q鍵離開。")
print("W：前進，S：後退，A：左轉，D：右轉")
print("F：順時針旋轉90度，G：逆時針旋轉90度")
print("C：回歸 (6.23, 0.0) 並朝向原點")
print("Q：離開")

while robot.step(TIME_STEP) != -1:
    key = keyboard.getKey()

    if key == ord('W') or key == ord('w'):
        velocity = MAX_VELOCITY
        set_wheel_velocity(velocity, velocity, velocity, velocity)
    elif key == ord('S') or key == ord('s'):
        velocity = -MAX_VELOCITY
        set_wheel_velocity(velocity, velocity, velocity, velocity)
    elif key == ord('D') or key == ord('d'):
        velocity = MAX_VELOCITY
        set_wheel_velocity(-velocity, velocity, -velocity, velocity)
    elif key == ord('A') or key == ord('a'):
        velocity = MAX_VELOCITY
        set_wheel_velocity(velocity, -velocity, velocity, -velocity)
    elif key == ord('F') or key == ord('f'):
        rotate_by_angle(90)
    elif key == ord('G') or key == ord('g'):
        rotate_by_angle(-90)
    elif key == ord('Q') or key == ord('q'):
        break
    elif key == ord('C') or key == ord('c'):
        print("執行 C：回歸 (6.23, 0.0) 並朝向原點")
        move_to_point_and_face_to((6.23, 0.0), (0.0, 0.0))
    else:
        set_wheel_velocity(0, 0, 0, 0)