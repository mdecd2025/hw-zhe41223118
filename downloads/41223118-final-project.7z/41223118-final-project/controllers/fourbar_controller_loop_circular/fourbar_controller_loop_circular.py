from controller import Robot, Receiver, Emitter
import math

# ==== Constants ====
TIME_STEP = 32
MAX_VELOCITY = 20.0

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Devices
receiver = robot.getDevice('rcv')
receiver.enable(timestep)

emitter = robot.getDevice('22')

gps = robot.getDevice('gps')
gps.enable(timestep)

imu = robot.getDevice('imu')
imu.enable(timestep)

wheels = [robot.getDevice(f"wheel{i+1}") for i in range(4)]
for wheel in wheels:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)

# 機械臂/打擊器裝置
try:
    motor = robot.getDevice('motor1')
    sensor = robot.getDevice('motor1_sensor')
    sensor.enable(timestep)
    mechanism_enabled = True
except Exception:
    mechanism_enabled = False

current_state = "allow_m"

def get_position():
    pos = gps.getValues()
    return (pos[0], pos[1])  # x, y

def get_yaw():
    return imu.getRollPitchYaw()[2]

def set_wheel_velocity(v1, v2, v3, v4):
    wheels[0].setVelocity(v1)
    wheels[1].setVelocity(v2)
    wheels[2].setVelocity(v3)
    wheels[3].setVelocity(v4)

def move_sideways_precise(distance, fast_velocity=MAX_VELOCITY, slow_velocity=2.0, tolerance=0.01):
    """
    精確橫向移動指定距離（右為正，左為負），快慢速切換
    """
    start_pos = get_position()
    yaw = get_yaw()
    side_vec = (math.sin(yaw), math.cos(yaw))
    while robot.step(TIME_STEP) != -1:
        now_pos = get_position()
        dx = now_pos[0] - start_pos[0]
        dy = now_pos[1] - start_pos[1]
        side_moved = dx * side_vec[0] + dy * side_vec[1]
        remain = distance - side_moved
        if abs(remain) < tolerance:
            break
        threshold = abs(distance) / 10.0
        v = fast_velocity if abs(remain) > threshold else slow_velocity
        direction = 1 if remain >= 0 else -1
        set_wheel_velocity(direction * v, -direction * v, -direction * v, direction * v)
    set_wheel_velocity(0, 0, 0, 0)
    print("Sideways move finished")

print("只處理 J 訊號自動平移/回傳 J 訊號，還有 a/m/k 動作")

first_j_received = False

while robot.step(timestep) != -1:
    while receiver.getQueueLength() > 0:
        msg = receiver.getString().strip().lower()
        # 平移功能
        if msg == 'j':
            if not first_j_received:
                print("收到第一次 J 訊號，執行側移 0.5m ...（不發J）")
                move_sideways_precise(0.5)
                first_j_received = True
            else:
                print("收到第 n 次 J 訊號，執行側移 0.5m 並發送J ...")
                emitter.send("J".encode("utf-8"))
                print("已發送 J 訊號")
                move_sideways_precise(0.5)
        # 機械臂/打擊器功能
        if mechanism_enabled:
            if msg == 'a':
                current_state = "allow_m"
            elif msg == 'm' and current_state == "allow_m":
                motor.setPosition(1.0)  # POSITION_M
                current_state = "allow_k"
                print("已執行 m 動作")
            elif msg == 'k' and current_state == "allow_k":
                motor.setPosition(0.0)  # POSITION_K
                current_state = "allow_m"
                print("已執行 k 動作")
        receiver.nextPacket()