from controller import Robot, Keyboard
import math

deg = math.pi / 180

# === 常數設定 ===
TIME_STEP = 16
WHEEL_RADIUS = 0.05
L = 0.56
W = 0.34
MAX_VELOCITY = 10.0

# === 初始化 ===
robot = Robot()
keyboard = Keyboard()
keyboard.enable(TIME_STEP)

imu = robot.getDevice("imu")
imu.enable(TIME_STEP)

gps = robot.getDevice("gps")
gps.enable(TIME_STEP)

wheels = [
    robot.getDevice("wheel1"),  # 右前
    robot.getDevice("wheel2"),  # 左前
    robot.getDevice("wheel3"),  # 右後
    robot.getDevice("wheel4")   # 左後
]
for wheel in wheels:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)

# === 工具函數 ===
def set_wheel_velocity(v1, v2, v3, v4):
    wheels[0].setVelocity(v1)
    wheels[1].setVelocity(v2)
    wheels[2].setVelocity(v3)
    wheels[3].setVelocity(v4)

def get_yaw():
    return imu.getRollPitchYaw()[2]

def get_position():
    pos = gps.getValues()
    return (pos[0], pos[1])

def angle_diff(a, b):
    d = a - b
    while d > math.pi:
        d -= 2 * math.pi
    while d < -math.pi:
        d += 2 * math.pi
    return d

def angle_between_vectors(ax, ay, bx, by):
    norm_a = math.hypot(ax, ay)
    norm_b = math.hypot(bx, by)
    ax, ay = ax / norm_a, ay / norm_a
    bx, by = bx / norm_b, by / norm_b
    dot = ax * bx + ay * by
    det = ax * by - ay * bx
    angle_rad = math.atan2(det, dot)
    return math.degrees(angle_rad)

# === 動作函數（同步） ===
def rotate_by_angle(target_angle_deg, fast_velocity=MAX_VELOCITY, slow_velocity=1.0, tolerance_deg=1.0):
    start_yaw = get_yaw()
    target_rad = math.radians(target_angle_deg)
    slow_zone = math.radians(5)
    direction = -1 if target_angle_deg > 0 else 1

    while True:
        robot.step(TIME_STEP)
        now_yaw = get_yaw()
        turned = angle_diff(now_yaw, start_yaw)
        remain = abs(target_rad) - abs(turned)

        if remain < math.radians(tolerance_deg):
            break

        if remain < slow_zone:
            speed = slow_velocity
        else:
            speed = fast_velocity

        set_wheel_velocity(-direction * speed, direction * speed,
                           -direction * speed, direction * speed)

    set_wheel_velocity(0, 0, 0, 0)
    print(f"[完成] 旋轉角度：{math.degrees(turned):.2f}°")

def move_to_point_and_face_to(target_point, face_to_point, tolerance_pos=0.05):
    fast_velocity = 10.0
    slow_velocity = 1.0
    MAX_STEP = 1200

    # === 第一階段：轉向目標點 ===
    now_pos = get_position()
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    tar_vec = (target_point[0] - now_pos[0], target_point[1] - now_pos[1])
    angle1 = angle_between_vectors(head_vec[0], head_vec[1], tar_vec[0], tar_vec[1])
    print(f"[階段1] 旋轉朝向目標點 {angle1:.2f}°")
    rotate_by_angle(angle1)

    # === 第二階段：前進 ===
    step = 0
    while step < MAX_STEP:
        robot.step(TIME_STEP)
        now_pos = get_position()
        dx = target_point[0] - now_pos[0]
        dy = target_point[1] - now_pos[1]
        dist = math.hypot(dx, dy)
        if dist < tolerance_pos:
            break

        v = fast_velocity if dist > 0.3 else slow_velocity
        set_wheel_velocity(v, v, v, v)
        step += 1
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(8):
        robot.step(TIME_STEP)
    print(f"[階段2] 到達目標點 (距離: {dist:.3f})")

    # === 第三階段：轉向 face_to_point ===
    now_pos = get_position()
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    face_vec = (face_to_point[0] - now_pos[0], face_to_point[1] - now_pos[1])
    angle2 = angle_between_vectors(head_vec[0], head_vec[1], face_vec[0], face_vec[1])
    print(f"[階段3] 最終朝向 (0,0) 旋轉 {angle2:.2f}°")
    rotate_by_angle(angle2)
    set_wheel_velocity(0, 0, 0, 0)
    for _ in range(8):
        robot.step(TIME_STEP)

# === 說明 ===
print("==== 你可以按下鍵盤執行命令 ====")
print("↑ ↓ ← →：手動移動")
print("V / B：旋轉 ±30°")
print("U：前往 (6.23, 6.05)，面向原點")
print("I：前往 (12.46, -0.18)，面向原點")
print("O：前往 (6.23, -6.41)，面向原點")
print("P：前往 (0, 0)，面向原點")
print("Q：離開模擬")

# === 主迴圈 ===
while robot.step(TIME_STEP) != -1:
    key = keyboard.getKey()

    if key == Keyboard.UP:
        set_wheel_velocity(MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY)
    elif key == Keyboard.DOWN:
        set_wheel_velocity(-MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY)
    elif key == Keyboard.RIGHT:
        set_wheel_velocity(-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY)
    elif key == Keyboard.LEFT:
        set_wheel_velocity(MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY)
    elif key == ord('V') or key == ord('v'):
        print("旋轉 +30 度")
        rotate_by_angle(30)
    elif key == ord('B') or key == ord('b'):
        print("旋轉 -30 度")
        rotate_by_angle(-30)
    elif key == ord('Q') or key == ord('q'):
        print("結束模擬")
        break
    elif key == ord('U') or key == ord('u'):
        print("執行 U：前往 (6.23, 6.05)，朝向 (0, 0)")
        move_to_point_and_face_to((6.23, 6.05), (6.23, 0.0))
    elif key == ord('I') or key == ord('i'):
        print("執行 I：前往 (12.46, -0.18)，朝向 (0, 0)")
        move_to_point_and_face_to((12.46, -0.18), (6.23, 0.0))
    elif key == ord('O') or key == ord('o'):
        print("執行 O：前往 (6.23, -6.41)，朝向 (0, 0)")
        move_to_point_and_face_to((6.23, -6.41), (6.23, 0.0))
    elif key == ord('P') or key == ord('p'):
        print("執行 P：前往 (0, 0)，朝向 (0, 0)")
        move_to_point_and_face_to((0.0, 0.0), (6.23, 0.0))
    else:
        set_wheel_velocity(0, 0, 0, 0)